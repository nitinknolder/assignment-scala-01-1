package edu.knoldus

class Searching {

  def binarySearch(array: Array[Int], elem: Int): Boolean = {
    //todo: Add Logic
    if (array.contains(elem)) {
      true
    }
    else {
      false
    }
  }

  def linearSearch(array: Array[Int], elem: Int): Boolean = {
    if (array.isEmpty) {
      -      println("Arraylist is empty...")
      return false
    }
    else if (array.head == elem) {
      -      println("Element Found!!!")
      return true
    }
    else {
      for (list1 <- array) {
        if (list1 == elem) {
          -          println("Element Found!!!")
          return true
        }
      }
}
