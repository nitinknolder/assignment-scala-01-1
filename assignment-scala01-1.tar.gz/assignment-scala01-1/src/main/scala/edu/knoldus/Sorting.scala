package edu.knoldus
class Sorting {
  class sorting {
    def insertionSort(array: Array[Int]): Array[Int] = {
      for (first <- 0 to array.length - 1) {
        val next = first + 1
        for (next <- first until 0 by -1) {
          if (array(next) < array(next - 1)) {
            val temp = array(next)
            array(next) = array(next - 1)
            array(next - 1) = temp
          }
        }
      }
      println(array)
      return array
    }
    def selectionSort(array: Array[Int]): Array[Int] = {
      for (first <- 0 until array.length - 1) {
        var min_index = first
        for (next <- first + 1 until array.length) {
          if (array(next) < array(first)) {
            min_index = next
          }
          val minimumval = array(next)
          array(next) = array(first)
          array(first) = minimumval
        }
      }
      println(array)
      return array
    }
  }
  def bubbleSort(array: Array[Int]): Array[Int] = {
    for (first <- 1 to array.length - 1) {
      for (next <- (first - 1) to 0 by -1) {
        if (array(next) > array(next + 1)) {
          val temp = array(next + 1)
          array(next + 1) = array(next)
          array(next) = temp
        }
      }
    }
    println(array)
    return array
  }
}
